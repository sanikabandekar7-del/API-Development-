
const express = require("express");

const app = express();
const PORT = 3000;

// Middleware to read JSON request bodies
app.use(express.json());

// Temporary student data
let students = [
  { id: 1, name: "Rahul", course: "BCA" },
  { id: 2, name: "Priya", course: "BSc IT" }
];

// 1. GET: Check whether the API is running
app.get("/", (req, res) => {
  res.json({ message: "Student API is running successfully!" });
});

// 2. GET: Retrieve all students
app.get("/api/students", (req, res) => {
  res.status(200).json(students);
});

// 3. GET: Retrieve a student by ID
app.get("/api/students/:id", (req, res) => {
  const student = students.find(
    s => s.id === Number(req.params.id)
  );

  if (!student) {
    return res.status(404).json({
      message: "Student not found"
    });
  }

  res.status(200).json(student);
});

// 4. POST: Add a new student
app.post("/api/students", (req, res) => {
  const { name, course } = req.body;

  if (!name || !course) {
    return res.status(400).json({
      message: "Name and course are required"
    });
  }

  const newStudent = {
    id: students.length
      ? Math.max(...students.map(s => s.id)) + 1
      : 1,
    name,
    course
  };

  students.push(newStudent);

  res.status(201).json({
    message: "Student added successfully",
    student: newStudent
  });
});

// 5. PUT: Update an existing student
app.put("/api/students/:id", (req, res) => {
  const student = students.find(
    s => s.id === Number(req.params.id)
  );

  if (!student) {
    return res.status(404).json({
      message: "Student not found"
    });
  }

  const { name, course } = req.body;

  if (!name || !course) {
    return res.status(400).json({
      message: "Name and course are required"
    });
  }

  student.name = name;
  student.course = course;

  res.status(200).json({
    message: "Student updated successfully",
    student
  });
});

// 6. DELETE: Remove a student
app.delete("/api/students/:id", (req, res) => {
  const index = students.findIndex(
    s => s.id === Number(req.params.id)
  );

  if (index === -1) {
    return res.status(404).json({
      message: "Student not found"
    });
  }

  students.splice(index, 1);

  res.status(200).json({
    message: "Student deleted successfully"
  });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
